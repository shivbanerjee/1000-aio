import os
import json

with open("info.json", "r") as f:
    config_data = json.load(f)

TOKEN = config_data.get("TOKEN", "")
No_Prefix = config_data.get("np", [])
NAME = config_data.get("BotName", "Nixo Devs")
server = config_data.get("serverLink", "")
ch = ""
OWNER_IDS = config_data.get("OWNER_IDS", [])
BotName = config_data.get("BotName", "Nixo Devs")
serverLink = config_data.get("serverLink", "")
whCL = config_data.get("wh_cl", "")
whBL = config_data.get("wh_bl", "")
statusText = config_data.get("statusText", ".help"),
np_webhook = config_data.get("np_webhook", "")