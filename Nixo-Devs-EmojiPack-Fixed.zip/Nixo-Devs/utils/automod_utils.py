import discord
from discord.ext import commands
from datetime import datetime
import os

class Embeds:
    COLOR = 0x2b2d31
    FOOTER = "Nixo Devs - AutoMod System"

    @staticmethod
    def success(text: str, footer: str = None) -> discord.Embed:
        embed = discord.Embed(
            description=f"> ✅ **Success:** {text}",
            color=Embeds.COLOR,
            timestamp=datetime.now()
        )
        embed.set_footer(text=footer or Embeds.FOOTER)
        return embed

    @staticmethod
    def error(text: str, footer: str = None) -> discord.Embed:
        embed = discord.Embed(
            description=f"> 🔹 **Error:** {text}",
            color=Embeds.COLOR,
            timestamp=datetime.now()
        )
        embed.set_footer(text=footer or Embeds.FOOTER)
        return embed

    @staticmethod
    def info(title: str, text: str, footer: str = None) -> discord.Embed:
        embed = discord.Embed(
            title=f"🔎 {title}",
            description=f"{text}",
            color=Embeds.COLOR,
            timestamp=datetime.now()
        )
        embed.set_footer(text=footer or Embeds.FOOTER)
        return embed

    @staticmethod
    def config(title: str, fields: dict, footer: str = None) -> discord.Embed:
        embed = discord.Embed(
            title=f"🛡️ {title} Configuration",
            color=Embeds.COLOR,
            timestamp=datetime.now()
        )
        desc = ""
        for key, value in fields.items():
            status = "Enabled" if value is True else "Disabled" if value is False else f"`{value}`"
            desc += f"- **{key}:** {status}\n"
        embed.description = desc
        embed.set_footer(text=footer or Embeds.FOOTER)
        return embed
