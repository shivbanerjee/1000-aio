"""Nixo Devs emoji-pack manager.

The bundled PNG pack is installed as Discord custom emojis only when a server
owner explicitly runs the install command. Until then, safe Unicode fallbacks
are returned so the bot never shows broken custom-emoji text.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Dict

import aiosqlite
import discord

DB_PATH = os.path.join("database", "nixo_emojis.db")
PACK_DIR = Path("assets/nixo_emoji_pack")

# Semantic names used by the bot. The filename is the bundled PNG name.
PACK_FILES = {
    "robot": "robot.png",
    "security": "security.png",
    "lock": "lockx.png",
    "unlock": "unlock.png",
    "settings": "settings.png",
    "home": "home.png",
    "admin": "admin-panel.png",
    "link": "linkx.png",
    "webhook": "webhook.png",
    "code": "code.png",
    "python": "python.png",
    "javascript": "java-script.png",
    "csharp": "c-sharp.png",
    "language": "language.png",
    "permission": "permission.png",
    "help": "help.png",
    "info": "infox.png",
    "check": "check.png",
    "accept": "accept.png",
    "remove": "remove.png",
    "removex": "removex.png",
    "add": "add.png",
    "add_user": "add-user.png",
    "ban": "ban-user.png",
    "member": "member-card.png",
    "prisoner": "prisoner.png",
    "logout": "logout.png",
    "microphone": "microphone.png",
    "volume": "volume-up.png",
    "mute": "mute.png",
    "deaf": "Deafan.png",
    "record": "record-button.png",
    "pause": "pause.png",
    "pause_play": "pause-play.png",
    "play": "play-buttton.png",
    "music": "music-player.png",
    "rapid": "rapid.png",
    "dollar": "dollar.png",
    "money": "money.png",
    "diamond": "dimond.png",
    "shop": "shopx.png",
    "ticket": "tickety.png",
    "claim": "claim.png",
    "battle": "battle.png",
    "king": "king.png",
    "crown": "crown.png",
    "game": "game-controller.png",
    "signal": "signal.png",
    "live": "live.png",
    "hashtag": "hashtag.png",
    "scan": "scan.png",
    "image": "image.png",
    "download": "downloadx.png",
    "file": "file.png",
    "folder": "open-folder.png",
    "door": "opened-door-aperture.png",
    "cloud": "cloud-computing.png",
    "social": "social-media.png",
    "social_alt": "social-mediax.png",
    "discord": "discord.png",
    "wifi": "wifi.png",
    "toggle": "toggle.png",
    "clock": "clock.png",
    "paint": "paint.png",
    "pencil": "pencil.png",
    "vinyl": "vinyl.png",
    "logo": "logo.png",
    "hacker": "hacker.png",
    "heart": "heart.png",
    "kick": "kick.png",
    "bin": "bin.png",
    "arrow_right": "arrow-right.png",
    "utility": "utility.png",
    "disabled": "disabled.png",
    "self_regulation": "self-regulation.png",
}

FALLBACKS = {
    "robot": "🤖", "security": "🛡️", "lock": "🔒", "unlock": "🔓",
    "settings": "⚙️", "home": "🏠", "admin": "👮", "link": "🔗",
    "webhook": "🕸️", "code": "💻", "python": "🐍", "javascript": "🟨",
    "csharp": "🟪", "language": "🌐", "permission": "🔑", "help": "❓",
    "info": "ℹ️", "check": "✅", "accept": "✅", "remove": "❌",
    "removex": "❌", "add": "➕", "add_user": "👤", "ban": "🚫",
    "member": "🪪", "prisoner": "⛓️", "logout": "🚪", "microphone": "🎙️",
    "volume": "🔊", "mute": "🔇", "deaf": "🔇", "record": "⏺️",
    "pause": "⏸️", "pause_play": "⏯️", "play": "▶️", "music": "🎵",
    "rapid": "⚡", "dollar": "💵", "money": "💰", "diamond": "💎",
    "shop": "🛒", "ticket": "🎟️", "claim": "🎁", "battle": "⚔️",
    "king": "♔", "crown": "👑", "game": "🎮", "signal": "📶", "live": "🟢",
    "hashtag": "#️⃣", "scan": "🔎", "image": "🖼️", "download": "📥",
    "file": "📄", "folder": "📁", "door": "🚪", "cloud": "☁️", "social": "🌐",
    "social_alt": "📱", "discord": "💬", "wifi": "📶", "toggle": "🔘",
    "clock": "🕒", "paint": "🎨", "pencil": "✏️", "vinyl": "💿", "logo": "◈",
    "hacker": "🕵️", "heart": "❤️", "kick": "👢", "bin": "🗑️",
    "arrow_right": "➡️", "utility": "🧰", "disabled": "🚫", "self_regulation": "🧘",
}

_CACHE: Dict[int, Dict[str, str]] = {}


def _emoji_name(key: str) -> str:
    safe = re.sub(r"[^a-z0-9_]+", "_", key.lower()).strip("_")
    return f"nxd_{safe}"[:32]


async def init_emoji_store() -> None:
    os.makedirs("database", exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "CREATE TABLE IF NOT EXISTS emojis (guild_id INTEGER NOT NULL, key TEXT NOT NULL, emoji_id INTEGER NOT NULL, name TEXT NOT NULL, PRIMARY KEY (guild_id, key))"
        )
        await db.commit()
        async with db.execute("SELECT guild_id, key, emoji_id, name FROM emojis") as cur:
            rows = await cur.fetchall()
    _CACHE.clear()
    for guild_id, key, emoji_id, name in rows:
        _CACHE.setdefault(int(guild_id), {})[key] = f"<:{name}:{emoji_id}>"


def get_pack_emoji(guild_id: int | None, key: str) -> str:
    if guild_id is not None:
        value = _CACHE.get(int(guild_id), {}).get(key)
        if value:
            return value
    return FALLBACKS.get(key, "🔹")


async def install_pack(guild: discord.Guild) -> tuple[int, int, list[str]]:
    """Install as many bundled emojis as the guild currently has capacity for."""
    me = guild.me
    if me is None:
        try:
            me = await guild.fetch_member(guild._state.user.id)
        except Exception:
            me = None
    if not me or not me.guild_permissions.manage_emojis_and_stickers:
        raise PermissionError("The bot needs Manage Expressions (Emojis and Stickers).")

    await init_emoji_store()
    created = 0
    existing = 0
    skipped: list[str] = []

    async with aiosqlite.connect(DB_PATH) as db:
        for key, filename in PACK_FILES.items():
            stored = _CACHE.get(guild.id, {}).get(key)
            if stored:
                existing += 1
                continue

            path = PACK_DIR / filename
            if not path.exists():
                skipped.append(f"{key} (missing file)")
                continue

            # Reuse a previously-created Nixo Devs emoji if it exists.
            target_name = _emoji_name(key)
            found = discord.utils.get(guild.emojis, name=target_name)
            if found:
                value = str(found)
                _CACHE.setdefault(guild.id, {})[key] = value
                await db.execute(
                    "INSERT OR REPLACE INTO emojis(guild_id,key,emoji_id,name) VALUES(?,?,?,?)",
                    (guild.id, key, found.id, found.name),
                )
                existing += 1
                continue

            if len(guild.emojis) >= guild.emoji_limit:
                skipped.append(f"{key} (emoji slot limit reached)")
                break

            try:
                data = path.read_bytes()
                emoji = await guild.create_custom_emoji(
                    name=target_name,
                    image=data,
                    reason="Nixo Devs bundled emoji pack",
                )
                value = str(emoji)
                _CACHE.setdefault(guild.id, {})[key] = value
                await db.execute(
                    "INSERT OR REPLACE INTO emojis(guild_id,key,emoji_id,name) VALUES(?,?,?,?)",
                    (guild.id, key, emoji.id, emoji.name),
                )
                created += 1
            except discord.HTTPException as exc:
                skipped.append(f"{key} ({exc.status})")
                if exc.status in (403, 30016, 40005):
                    break
        await db.commit()

    return created, existing, skipped

# Legacy/custom-emoji names found in the source. They are resolved to the
# Nixo Devs pack when installed, otherwise to a Unicode fallback.
LEGACY_ALIASES = {
    "wallet": "dollar", "benk": "money", "money": "money", "icons_money": "money",
    "NixoDevsDoubleTick": "check", "NixoDevsExcl": "remove", "emoji_1769867605256": "check",
    "emoji_1769867589372": "remove", "NixoDevsUsage": "code", "NixoDevsAlias": "link",
    "NixoDevsInfo": "info", "NixoDevsShield": "security", "NixoDevsPin": "lock",
    "NixoDevsPencil": "pencil", "NixoDevsFire": "rapid", "NixoDevsEye": "scan",
    "NixoDevsTotal": "money", "NixoDevsHuman": "member", "NixoDevs": "robot",
    "IconsDanger": "remove", "icons_add": "add", "icons_removed": "remove",
    "icons_user": "member", "icons_roles": "permission", "icons_moderation": "security",
    "icons_channel": "hashtag", "icons_voice": "microphone", "icons_ticket": "ticket",
    "icons_verify": "check", "icons_linkadd": "link", "icons_edit": "pencil",
    "icons_bots": "robot", "icons_utility": "utility", "icons_richpresence": "live",
    "icons_star": "heart", "icons_tag": "hashtag", "Customroles": "settings",
    "lock": "lock", "unlock": "unlock", "hide": "disabled", "invite": "add_user",
    "ban": "ban", "permit": "permission", "rename": "pencil", "bitrate": "settings",
    "region": "signal", "template": "file", "chat": "discord", "waiting": "clock",
    "vmclaim": "claim", "transfer": "link", "limit": "settings",
    "timeout": "clock", "exclaim": "info", "eye_automod": "scan", "flaggedsy": "security",
    "frozenstar": "heart", "gunlock": "lock", "rlock": "lock", "save": "check",
}


def normalize_emoji_text(guild_id: int | None, text: str | None) -> str | None:
    """Replace stale custom emoji tokens with installed Nixo pack emojis/fallbacks."""
    if not text:
        return text

    def repl(match: re.Match[str]) -> str:
        name = match.group("name")
        key = LEGACY_ALIASES.get(name)
        if key is None:
            low = name.lower()
            key = LEGACY_ALIASES.get(low)
        if key is None:
            return match.group(0)
        return get_pack_emoji(guild_id, key)

    return re.sub(r"<a?:(?P<name>[A-Za-z0-9_]+):\d+>", repl, text)
