# Nixo Devs

Developer: Ghost

This package is the Nixo Devs-branded derivative of the supplied Discord bot source.
