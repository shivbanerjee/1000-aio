from __future__ import annotations

from discord.ext import commands
import discord
import functools
from typing import Optional, Any
from utils.nixo_emojis import normalize_emoji_text
import asyncio

__all__ = ("Context", )


class Context(commands.Context):

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)

    def __repr__(self):
        return "<core.Context>"

    @property
    async def session(self):
        return self.bot.session

    @discord.utils.cached_property
    def replied_reference(self) -> Optional[discord.Message]:
        ref = self.message.reference
        if ref and isinstance(ref.resolved, discord.Message):
            return ref.resolved.to_reference()
        return None

    def with_type(func):

        @functools.wraps(func)
        async def wrapped(self, *args, **kwargs):
            context = args[0] if isinstance(args[0],
                                            commands.Context) else args[1]
            try:
                async with context.typing():
                    await func(*args, **kwargs)
            except discord.Forbidden:  
                await func(*args, **kwargs)

        return wrapped

    async def show_help(self, command: str = None) -> Any:
        cmd = self.bot.get_command('help')
        command = command or self.command.qualified_name
        await self.invoke(cmd, command=command)

    async def send(self,
                   content: Optional[str] = None,
                   **kwargs) -> Optional[discord.Message]:
        if not (self.channel.permissions_for(self.me)).send_messages:
            try:
                await self.author.send(
                    "Nixo Devs dont have perms to send msg in that channel")
            except discord.Forbidden:  
                pass
            return
        content = normalize_emoji_text(getattr(self.guild, "id", None), content)
        if "embed" in kwargs and kwargs["embed"] is not None:
            data = kwargs["embed"].to_dict()
            def _walk(value):
                if isinstance(value, str):
                    return normalize_emoji_text(getattr(self.guild, "id", None), value)
                if isinstance(value, dict):
                    return {k: _walk(v) for k, v in value.items()}
                if isinstance(value, list):
                    return [_walk(v) for v in value]
                return value
            kwargs["embed"] = discord.Embed.from_dict(_walk(data))
        if "embeds" in kwargs and kwargs["embeds"]:
            converted = []
            for emb in kwargs["embeds"]:
                data = emb.to_dict()
                def _walk2(value):
                    if isinstance(value, str):
                        return normalize_emoji_text(getattr(self.guild, "id", None), value)
                    if isinstance(value, dict):
                        return {k: _walk2(v) for k, v in value.items()}
                    if isinstance(value, list):
                        return [_walk2(v) for v in value]
                    return value
                converted.append(discord.Embed.from_dict(_walk2(data)))
            kwargs["embeds"] = converted
        return await super().send(content, **kwargs)

    async def reply(self,
                    content: Optional[str] = None,
                    **kwargs) -> Optional[discord.Message]:
        if not (self.channel.permissions_for(self.me)).send_messages:
            try:
                await self.author.send(
                    "Nixo Devs dont have perms to send msg in that channel")
            except discord.Forbidden:  
                pass
            return
        content = normalize_emoji_text(getattr(self.guild, "id", None), content)
        if "embed" in kwargs and kwargs["embed"] is not None:
            data = kwargs["embed"].to_dict()
            def _walk(value):
                if isinstance(value, str):
                    return normalize_emoji_text(getattr(self.guild, "id", None), value)
                if isinstance(value, dict):
                    return {k: _walk(v) for k, v in value.items()}
                if isinstance(value, list):
                    return [_walk(v) for v in value]
                return value
            kwargs["embed"] = discord.Embed.from_dict(_walk(data))
        if "embeds" in kwargs and kwargs["embeds"]:
            converted = []
            for emb in kwargs["embeds"]:
                data = emb.to_dict()
                def _walk2(value):
                    if isinstance(value, str):
                        return normalize_emoji_text(getattr(self.guild, "id", None), value)
                    if isinstance(value, dict):
                        return {k: _walk2(v) for k, v in value.items()}
                    if isinstance(value, list):
                        return [_walk2(v) for v in value]
                    return value
                converted.append(discord.Embed.from_dict(_walk2(data)))
            kwargs["embeds"] = converted
        return await super().reply(content, **kwargs)

    async def release(self, delay: Optional[int] = None) -> None:
        delay = delay or 0
        await asyncio.sleep(delay)