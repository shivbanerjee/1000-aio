# Nixo Devs

Nixo Devs is a multi-purpose Discord bot built with `discord.py`, focused on moderation, security, automation, utility, engagement, economy, games, roles, social features, and voice tools.

## Developer

**Ghost**

## Features

- Antinuke & security
- Moderation and automod
- Economy and games
- Utility and administration
- Role management
- Automation and engagement
- Social and entertainment tools
- Voice and music features

## Requirements

- Python 3.10+
- A Discord bot application/token
- Dependencies from `requirements.txt`

## Setup

1. Install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Put your Discord bot token and owner IDs in `info.json`.
3. Start the bot:
   ```bash
   python app.py
   ```

## Configuration

`info.json` contains the bot token, owner IDs, bot name, status, support-server link, and optional webhook settings. Keep the bot token private and never commit a real token to a public repository.

## License

This distribution is licensed under the MIT License. The original MIT copyright notice is retained in `LICENSE` because this codebase is a derivative of the supplied source. Nixo Devs branding and modifications are attributed to Ghost.

## Nixo Devs Emoji Pack

The project includes a bundled icon pack under `assets/nixo_emoji_pack/`.

After inviting the bot to a server, the server owner can run:

```text
.nixoemoji install
```

The bot will install as many pack icons as the server's available custom-emoji slots allow and remember their IDs per server. Until installed, Nixo Devs uses Unicode fallbacks so missing custom emojis never appear as raw `:name:` text.

Pack attribution is retained in `assets/nixo_emoji_pack/@ShayanXiters.txt`.
