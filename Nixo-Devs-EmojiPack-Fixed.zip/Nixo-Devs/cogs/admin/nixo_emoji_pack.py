from __future__ import annotations

import discord
from discord.ext import commands

from utils.nixo_emojis import PACK_FILES, get_pack_emoji, init_emoji_store, install_pack


class NixoEmojiPack(commands.Cog):
    """Installs and manages the bundled Nixo Devs custom emoji pack."""

    def __init__(self, bot):
        self.bot = bot

    @commands.group(name="nixoemoji", aliases=["emoji-pack"], invoke_without_command=True)
    @commands.guild_only()
    async def nixoemoji(self, ctx: commands.Context):
        embed = discord.Embed(
            title="Nixo Devs • Emoji Pack",
            description=(
                f"Bundled icons: **{len(PACK_FILES)}**\n\n"
                "Use `.nixoemoji install` to add the pack to this server. "
                "The bot needs **Manage Expressions** and the server must have enough emoji slots."
            ),
            color=0x2B2D31,
        )
        embed.set_footer(text="Nixo Devs • Developer: Ghost")
        await ctx.reply(embed=embed, mention_author=False)

    @nixoemoji.command(name="install")
    @commands.guild_only()
    async def install(self, ctx: commands.Context):
        """Install the bundled Nixo Devs emoji pack in this server."""
        if ctx.author.id != ctx.guild.owner_id and not await self.bot.is_owner(ctx.author):
            return await ctx.reply(
                f"{get_pack_emoji(ctx.guild.id, 'remove')} Only the server owner or bot owner can install the Nixo Devs emoji pack.",
                mention_author=False,
            )

        me = ctx.guild.me
        if not me or not me.guild_permissions.manage_emojis_and_stickers:
            return await ctx.reply(
                f"{get_pack_emoji(ctx.guild.id, 'remove')} I need **Manage Expressions** to install the emoji pack.",
                mention_author=False,
            )

        msg = await ctx.reply(
            f"{get_pack_emoji(ctx.guild.id, 'rapid')} Installing **{len(PACK_FILES)}** Nixo Devs icons... This can take a little while.",
            mention_author=False,
        )
        try:
            created, existing, skipped = await install_pack(ctx.guild)
        except PermissionError as exc:
            return await msg.edit(content=f"{get_pack_emoji(ctx.guild.id, 'remove')} {exc}")
        except Exception as exc:
            return await msg.edit(content=f"{get_pack_emoji(ctx.guild.id, 'remove')} Emoji installation failed: `{type(exc).__name__}: {exc}`")

        text = (
            f"{get_pack_emoji(ctx.guild.id, 'check')} **Nixo Devs Emoji Pack installed.**\n"
            f"Created: **{created}**\n"
            f"Already installed: **{existing}**\n"
            f"Skipped: **{len(skipped)}**"
        )
        if skipped:
            preview = ", ".join(skipped[:8])
            if len(skipped) > 8:
                preview += f" … +{len(skipped) - 8} more"
            text += f"\n\nSkipped details: `{preview}`"
        await msg.edit(content=text)

    @nixoemoji.command(name="list")
    @commands.guild_only()
    async def list_installed(self, ctx: commands.Context):
        await init_emoji_store()
        count = len(__import__("utils.nixo_emojis", fromlist=["_CACHE"])._CACHE.get(ctx.guild.id, {}))
        await ctx.reply(
            f"{get_pack_emoji(ctx.guild.id, 'info')} Nixo Devs pack: **{count}/{len(PACK_FILES)}** icons installed in this server.",
            mention_author=False,
        )


async def setup(bot):
    await bot.add_cog(NixoEmojiPack(bot))
